from django.apps import AppConfig


class LoggerConfig(AppConfig):
    name = 'drf_api_logger_with_user'
    verbose_name = 'DRF API Logger'
